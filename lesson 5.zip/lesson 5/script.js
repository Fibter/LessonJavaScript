
const lenght = 4;
const valueToFill = 'hello'

const fillArray = (lenght, valueToFill) => {
    let finnalArray = [];
    for (let i = 0; i < lenght; i++)
        finnalArray.push(valueToFill);

    return finnalArray;
};

console.log(fillArray(lenght, valueToFill))


let obj = {
    width: 10,
    height: 5,
    title: 'Test Array',
    count: 4
};



const multiplyNumeric = (obj) => {
    if (typeof obj !== 'object' || !obj || Array.isArray(obj)) return 'Error';
    for (let key in obj) {
        if (typeof obj[key] === 'number') {
            obj[key] **= 2;
        }
    }
    return obj;
}
console.log(multiplyNumeric(obj))





















